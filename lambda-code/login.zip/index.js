exports.handler = async (event) => {
    // Your login logic here
    const response = {
        statusCode: 200,
        body: JSON.stringify('User logged in successfully!'),
    };
    return response;
};